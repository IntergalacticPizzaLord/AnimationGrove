const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0xffffff);
document.body.appendChild(renderer.domElement);

const hemisphereLight = new THREE.HemisphereLight(0xffffff, 0xffffff, 0.25);
scene.add(hemisphereLight);

const ambientLight = new THREE.AmbientLight(0xffffff, 0.25);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, .5);
directionalLight.position.set(-0.5, 2.5, 5);
directionalLight.shadow.camera.left = 5 * -100;
directionalLight.shadow.camera.bottom = 5 * -100;
directionalLight.shadow.camera.right = 5 * 100;
directionalLight.shadow.camera.top = 5 * 100;
directionalLight.shadow.camera.near = 10;
directionalLight.shadow.camera.far = 500;
scene.add(directionalLight);


// Rest of your code remains the same...

const dracoLoader = new THREE.DRACOLoader();
dracoLoader.setDecoderPath("https://www.gstatic.com/draco/v1/decoders/");
const gltfLoader = new THREE.GLTFLoader();
gltfLoader.setDRACOLoader(dracoLoader);

const textureLoader = new THREE.TextureLoader();

// Load the sky gradient texture
const skyGradientTexture = textureLoader.load(
  "https://friendsies.io/textures/skyGradients/skyGradientTen.png"
);
skyGradientTexture.flipY = true;
skyGradientTexture.wrapS = skyGradientTexture.wrapT = THREE.RepeatWrapping;

// Create the sky dome mesh
const skyDomeGeometry = new THREE.PlaneBufferGeometry(250, 75);
const skyDomeMaterial = new THREE.MeshBasicMaterial({
  map: skyGradientTexture,
  side: THREE.FrontSide,
  fog: false
});
const skyDomeMesh = new THREE.Mesh(skyDomeGeometry, skyDomeMaterial);
skyDomeMesh.position.set(0, 18, -50);
scene.add(skyDomeMesh);

let loadedModels = [];
let allfRiENDSiES;

fetch(
  "https://gist.githubusercontent.com/IntergalacticPizzaLord/a7b0eeac98041a483d715c8320ccf660/raw/ce7d37a94c33c63e2b50d5922e0711e72494c8dd/fRiENDSiES"
)
  .then((response) => response.json())
  .then((data) => {
    allfRiENDSiES = data;
    initializeScene();
    document.getElementById("fRiENDSiESNumber").value = "2";
    loadfRiENDSiES();
  });

function initializeScene() {
  const pmremGenerator = new THREE.PMREMGenerator(renderer);
  pmremGenerator.compileEquirectangularShader();

  const hdrLoader = new THREE.RGBELoader();
  hdrLoader.setDataType(THREE.UnsignedByteType);
  hdrLoader.load(
    "https://hdrihaven.com/files/hdris/lebombo_1k.hdr",
    (texture) => {
      const envMap = pmremGenerator.fromEquirectangular(texture).texture;
      scene.environment = envMap;
      texture.dispose();
      pmremGenerator.dispose();
    }
  );
}

function loadfRiENDSiES() {
  loadedModels.forEach((model) => {
    scene.remove(model);
  });
  loadedModels = [];

  const number = document.getElementById("fRiENDSiESNumber").value - 0;
  const fRiENDSiES = allfRiENDSiES[number - 0];
  const attributes = fRiENDSiES.attributes;

  const faceAttribute = attributes.find(
    (attribute) => attribute.trait_type === "face"
  );
  let faceTexture = null;
  if (faceAttribute) {
    const facePngUrl = faceAttribute.asset_url;
    faceTexture = textureLoader.load(facePngUrl);
    faceTexture.minFilter = THREE.LinearFilter;
    faceTexture.repeat.y = -1;
    faceTexture.offset.y = 1;
  }

  const headAttribute = attributes.find(
    (attribute) => attribute.trait_type === "head"
  );
  if (headAttribute) {
    const headUrl = headAttribute.asset_url;
    gltfLoader.load(headUrl, (gltf) => {
      const headModel = gltf.scene;
      headModel.scale.set(15, 15, 15);
      headModel.position.y -= 2.5;

      headModel.traverse((child) => {
        if (child.isMesh && child.material.emissiveMap) {
          child.material.emissive = new THREE.Color(0xffffff);
          child.material.emissiveIntensity = 2.3;
        }
      });

      scene.add(headModel);
      loadedModels.push(headModel);
      animateModel(headModel);

      if (faceAttribute) {
        const faceMesh = headModel.clone();
        const faceMaterial = new THREE.MeshStandardMaterial({
          map: faceTexture,
          transparent: true,
          alphaTest: 0.5
        });
        faceMesh.traverse((child) => {
          if (child.isMesh) {
            child.material = faceMaterial;
          }
        });
        scene.add(faceMesh);
        loadedModels.push(faceMesh);
        animateModel(faceMesh);
      }
    });
  }

  attributes
    .filter(
      (attribute) =>
        attribute.trait_type !== "head" && attribute.trait_type !== "face"
    )
    .forEach((attribute) => {
      const assetUrl = attribute.asset_url;
      gltfLoader.load(assetUrl, (gltf) => {
        const model = gltf.scene;
        model.scale.set(15, 15, 15);
        model.position.y -= 2.5;

        scene.add(model);
        loadedModels.push(model);
        animateModel(model);
      });
    });
}

camera.position.z = 5;

const animateModel = (model) => {
  const animate = () => {
    requestAnimationFrame(animate);

    // Add sky dome animation (Optional)
    //skyGradientTexture.offset.set(performance.now() / 8000, 0);

    model.rotation.y += 0.01;
    renderer.render(scene, camera);
  };
  animate();
};

window.addEventListener("load", () => {
  document.getElementById("fRiENDSiESNumber").value = "7";
  loadfRiENDSiES();
});

window.addEventListener("resize", () => {
  const newWidth = window.innerWidth;
  const newHeight = window.innerHeight;

  camera.aspect = newWidth / newHeight;
  camera.updateProjectionMatrix();

  renderer.setSize(newWidth, newHeight);
});